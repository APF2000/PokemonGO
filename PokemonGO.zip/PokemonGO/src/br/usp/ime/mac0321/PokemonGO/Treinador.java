package br.usp.ime.mac0321.PokemonGO;

public class Treinador {
	private String nome;
	private Pokemon[] Pokedex;
	private int selecao = 0;
	
	public String selectPoke (int selecao) {
		this.selecao=selecao;
		return(nome + " selecionou " + pokedex[selecao].getNome)
	}
	
	
	
}

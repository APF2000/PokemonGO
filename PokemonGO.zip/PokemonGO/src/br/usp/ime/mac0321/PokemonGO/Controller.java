package br.usp.ime.mac0321.PokemonGO;

public class Controller {

}
